Los roles se escriben en singular y en minúscula sin espacios por ejemplo:

`admin`

`doctor`

`patient`

`assistant`
