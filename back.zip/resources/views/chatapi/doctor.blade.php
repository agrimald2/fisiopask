*FISIOSALUD: TIENES UNA NUEVA CITA*

*Paciente:*
{{ $patientName }}
*Fecha de cita:*
{{ $date }}
*Hora de cita:*
{{ $startTime }}
