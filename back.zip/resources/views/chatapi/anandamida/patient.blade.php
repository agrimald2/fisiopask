*ANANDAMIDA: CONFIRMACIÓN DE CITA*

*Paciente:*
{{ $patientName }}
*Fecha de cita:*
{{ $date }}
*Hora de cita:*
{{ $startTime }}
*DIRECCIÓN:*
???
*REFERENCIA:*
???
*Fisioterapeuta:*
{{ $doctorName }}
Ver / Cancelar tus citas aquí:
{{ $dashboardLink }}
Ver *mapa* aquí:
???
Ver *protocolo sanitario* aquí:
???

Te esperamos, Anandamida.

*Por favor, agréganos a tus contactos para activar los links*
