*ANANDAMIDA: CONFIRMACIÓN DE CITA*

*Paciente:*
{{ $patientName }}
*Fecha de cita:*
{{ $date }}
*Hora de cita:*
{{ $startTime }}
