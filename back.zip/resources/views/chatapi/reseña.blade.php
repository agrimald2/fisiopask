*Hola {{ $patientName }}! Muchas gracias por tus 5 estrellas!*


Esperamos que hayas disfrutado tu atención en *FISIOSALUD*


Te invitamos a dejarnos una reseña en Google! Para acceder a promociones exclusivas:


https://google.fisiosalud.pe/


Agradecemos de antemano tu colaboración y estamos contentos de que disfrutes de nuestro servicio.
