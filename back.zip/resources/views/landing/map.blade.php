<div class="st-google-map" style="display:flex; justify-content: center;">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.309253322474!2d-77.01651548459375!3d-12.09096859143783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105c9f9db2c1699%3A0xab591f993509975!2sFISIOSALUD%20-%20Centro%20de%20Rehabilitaci%C3%B3n%20y%20Fisioterapia!5e0!3m2!1ses!2sde!4v1640420301871!5m2!1ses!2sde"
        allowfullscreen
        class="map"
        >
    </iframe>
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.309253322474!2d-77.01651548459375!3d-12.09096859143783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105c9f9db2c1699%3A0xab591f993509975!2sFISIOSALUD%20-%20Centro%20de%20Rehabilitaci%C3%B3n%20y%20Fisioterapia!5e0!3m2!1ses!2sde!4v1640420301871!5m2!1ses!2sde"
        allowfullscreen
        class="map"
        >
    </iframe>
</div>
<style>
    .map{
        width:45%!important;
        padding: 1.5%;
    }
</style>