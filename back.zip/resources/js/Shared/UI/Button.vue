<template>
  <button class="bg-gray-900 text-white py-2 px-4 rounded hover:scale-105 transform transition-transform">
    <slot></slot>
  </button>
</template>


<script>
export default {
  props: [],

  components: {
    //
  },

  data() {
    return {
      //
    };
  },
};
</script>
