<template>
  <th class="border-blue-400 text-blue-600 border px-2 sm:px-2 lg:px-4 py-2">
    <slot />
  </th>
</template>
