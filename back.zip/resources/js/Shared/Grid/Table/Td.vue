<template>
  <td class="border px-2 sm:px-2 lg:px-4 py-2">
    <slot />
  </td>
</template>
