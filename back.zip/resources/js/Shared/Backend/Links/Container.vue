<template>
  <div class="mt-12 sm:p-2 sm:mx-4">
    <slot></slot>
  </div>
</template>
