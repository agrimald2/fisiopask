<template>
  <div class="mx-auto lg:max-w-5xl">
    <div class="grid
      gap-4 lg:gap-x-6 xl:gap-x-8
      grid-cols-2 lg:grid-cols-3
      2xl:grid-cols-4">
      <slot />
    </div>

  </div>
</template>
