<template>
  <div class="border-t my-12 lg:my-24 lg:max-w-5xl lg:mx-auto"></div>
</template>
