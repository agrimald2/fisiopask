<template>
  <div class="text-sm uppercase font-bold tracking-wider text-gray-400 text-center pb-6">
    <slot />
  </div>
</template>


<script>
export default {
  props: [],

  components: {
    //
  },

  data() {
    return {
      //
    };
  },
};
</script>
