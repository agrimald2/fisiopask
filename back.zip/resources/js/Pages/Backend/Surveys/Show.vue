<template>
  <JetFormSection @submitted="onSubmitted">
    
    <template #title>
      Ver Encuesta
    </template>

    <template #form>

    </template>

  </JetFormSection>
</template>

<script>
import JetFormSection from "@/Jetstream/FormSection.vue";

export default {
    components: {
        JetFormSection,
    },

    setup() {
        
    },
}
</script>