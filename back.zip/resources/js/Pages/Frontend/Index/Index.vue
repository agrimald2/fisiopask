<template>
  <div class="">Hola</div>
</template>


<script>
export default {
  props: [],

  components: {
    //
  },

  data() {
    return {
      //
    };
  },
};
</script>
