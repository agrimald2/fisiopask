<template>
  <div class="text-center text-4xl text-green-400">
    <i class="fas fa-spinner animate-spin"></i>
  </div>
</template>


<script>
export default {
  props: [],

  components: {
    //
  },

  data() {
    return {
      //
    };
  },
};
</script>
