<template>
  <div class="mt-6 max-w-md mx-auto px-2">
    <slot></slot>
  </div>
</template>
