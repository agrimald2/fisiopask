<template>
  <img
    src="/assets/logo.png"
    alt=""
  >
</template>
