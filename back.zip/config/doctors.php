<?php

return [

    'sex' => [
        'M' => 'Masculino',
        'F' => 'Femenino'
    ],

    'document_type' => [
        1 => 'DNI',
        2 => 'CARNET EXTRANJERIA',
        3 => 'RUC',
        4 => 'PASAPORTE',
        5 => 'PARTIDA DE NACIMIENTO',
        6 => 'OTROS'
    ],

];
